package modelo;
    import java.sql.Statement;
    import java.sql.Connection;
    import java.sql.DriverManager;
    import java.sql.ResultSet;
    import java.sql.SQLException;

public class GestionBD {
  
public class Conectar {
        Connection conexion=null;
        Statement sentencia=null;
        String BD="id2566579_trex";
        String url="jdbc:mysql://localhost/"+BD;
        String usuario="id2566579_epr2";
        String pass="12345";

        public String ingresarLogin(String nomUsuario,String contraseña){
            try{
        Class.forName("org.mysql.Driver");
        conexion=DriverManager.getConnection(url,usuario,pass);
        sentencia=conexion.createStatement();
        String sql="insert into login(usuario,contraseña)"+
                "values('"+nomUsuario+"','"+contraseña+"')";
        sentencia.executeQuery(sql);
        sentencia.close();
        conexion.close();
        return "Datos ingresados con exito";
        }catch(ClassNotFoundException | SQLException e){
        return "Error: "+e.getMessage();
        }
    }
        public String ingresarPuntaje(int puntaje){
            try{
        Class.forName("org.mysql.Driver");
        conexion=DriverManager.getConnection(url,usuario,pass);
        sentencia=conexion.createStatement();
        String sql="insert into puntaje(puntaje)"+
                "values("+puntaje+")";
        sentencia.executeQuery(sql);
        sentencia.close();
        conexion.close();
        return "Datos ingresados con exito";
        }catch(ClassNotFoundException | SQLException e){
        return "Error: "+e.getMessage();
        }
    }
}
    
    
}
